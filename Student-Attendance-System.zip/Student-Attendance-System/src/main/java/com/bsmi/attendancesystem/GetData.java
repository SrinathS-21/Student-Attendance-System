package com.bsmi.attendancesystem;

public class GetData {
    public static String username;
    public static String userRole;
    public static String path;
}
